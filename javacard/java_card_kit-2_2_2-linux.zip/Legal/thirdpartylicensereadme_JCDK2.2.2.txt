
DO NOT TRANSLATE OR LOCALIZE.

%% The following software files may be included in this product:  bn16.c, bn16.h, lbn.h, lbn16.c, lbn16.h, lbnmem.c, and lbnmem.h (collectively, "Colin Plumb Materials").  Use of any of the Colin Plumb Materials is governed by the additional license term below: 

You must reproduce and include in all copies of the Colin Plumb Code prepared by you, and in all adaptations thereof, the copyright notice(s) and proprietary legends of Colin Plumb as they appear in the Colin Plumb Code supplied by Sun to you.

